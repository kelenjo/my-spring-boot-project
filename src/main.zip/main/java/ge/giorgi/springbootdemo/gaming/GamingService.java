package ge.giorgi.springbootdemo.gaming;

import ge.giorgi.springbootdemo.gaming.models.CompanyDTO;
import ge.giorgi.springbootdemo.gaming.models.GameDTO;
import ge.giorgi.springbootdemo.gaming.models.PersonDTO;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class GamingService {

    private List<CompanyDTO> companies=new ArrayList<>();


}
