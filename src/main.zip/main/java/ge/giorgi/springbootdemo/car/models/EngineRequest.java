package ge.giorgi.springbootdemo.car.models;

public class EngineRequest {

    private int horsePower;
    private double capacity;

    public EngineRequest(int horsePower, double capacity) {
        this.horsePower = horsePower;
        System.out.println(horsePower + "from contsructori");
        this.capacity = capacity;
    }

    public int getHorsePower() {
        return horsePower;
    }

    public void setHorsePower(int horsePower) {
        this.horsePower = horsePower;
    }

    public double getCapacity() {
        return capacity;
    }

    public void setCapacity(double capacity) {
        this.capacity = capacity;
    }
}

