package ge.giorgi.springbootdemo.car.persistence;


import jakarta.persistence.*;

@Entity
@Table
@SequenceGenerator(name = "car_seq_gen", sequenceName = "car_seq", allocationSize = 1)
public class Car {
    @Id
    @GeneratedValue(generator = "car_seq_gen", strategy = GenerationType.SEQUENCE)
    private long id;

    @Column(name = "model")
    private String model;

    @Column(name = "year")
    private int year;

    @Column(name = "is_driving")
    private boolean driveable;

    @ManyToOne
    @JoinColumn(name = "engine_id")
    private Engine engine;

    public long getId() {
        return id;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Engine getEngine() {
        return engine;
    }

    public void setEngine(Engine engine) {
        this.engine = engine;
    }

    public boolean isDriveable() {
        return driveable;
    }

    public void setDriveable(boolean driveable) {
        this.driveable = driveable;
    }

}