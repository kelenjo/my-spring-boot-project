package ge.giorgi.springbootdemo.car.models;

public class EngineDTO {
    private long id;
    private int horsePower;
    private double capacity;

    public EngineDTO(long id, int horsePower, double capacity){
        this.id=id;
        this.horsePower=horsePower;
        this.capacity=capacity;
    }
    public void printInf(){
        System.out.println("Horse power is " + horsePower);
        System.out.println("Engine Capacity is "+ capacity);
    }

    public long getId(){return id;}
    public int getHorsePower(){
        return horsePower;
    }
    public double getCapacity(){
        return capacity;
    }

    public void setHorsePower(int horsepower) {
        this.horsePower = horsepower;
    }

    public void setCapacity(double capacity) {
        this.capacity = capacity;
    }

}
