package ge.giorgi.springbootdemo.car;


import ge.giorgi.springbootdemo.car.models.EngineDTO;
import ge.giorgi.springbootdemo.car.models.EngineRequest;
import ge.giorgi.springbootdemo.car.persistence.Engine;
import ge.giorgi.springbootdemo.car.persistence.EngineRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EngineService {

    private final EngineRepository engineRepository;

    public EngineService(EngineRepository engineRepository){
        this.engineRepository=engineRepository;
    }

    private EngineDTO mapEngine(Engine engine){
        return new EngineDTO(
                engine.getId(),
                engine.getHorsePower(),
                engine.getCapacity());
    }
    public Page<EngineDTO> getEngines(int page, int pageSize, double capacity) {
        return engineRepository.findEngines(capacity, PageRequest.of(page, pageSize));
    }
    public EngineDTO getEngine(long id){
        Engine engine=engineRepository.findById(id).orElse(null);
        if(engine!=null)
            return mapEngine(engine);
        return null;
    }
    public void createEngine(EngineRequest engineRequest) {
        Engine engine = new Engine();
        engine.setHorsePower(engineRequest.getHorsePower());
//        System.out.println(engineRequest.getHorsePower() + "from create engine");
        engine.setCapacity(engineRequest.getCapacity());
        engineRepository.save(engine);
//        System.out.println(engine.getHorsePower() + " from saved engine");
    }

    public void deleteEngine(long id){
        engineRepository.deleteById(id);
    }

    public EngineDTO upadateEngine(long  id, EngineRequest engineRequest) {
        Engine engine=engineRepository.findById(id).orElse(null);
        if(engine!=null){
            engine.setHorsePower(engineRequest.getHorsePower());
            engine.setCapacity(engineRequest.getCapacity());
            engineRepository.save(engine);
            return mapEngine(engine);
        }
        return null;

    }
    public Engine findEngine(long id){
        return engineRepository.findById(id).get();
    }
}

