package ge.giorgi.springbootdemo.car;


import ge.giorgi.springbootdemo.car.models.CarDTO;
import ge.giorgi.springbootdemo.car.models.CarRequest;
import ge.giorgi.springbootdemo.car.models.EngineDTO;
import ge.giorgi.springbootdemo.car.persistence.Car;
import ge.giorgi.springbootdemo.car.persistence.CarRepository;
import ge.giorgi.springbootdemo.car.persistence.EngineRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;


@Service
public class CarService {

    private final CarRepository carRepository;
    private final EngineService engineService;

    public CarService(CarRepository carRepository, EngineService engineService) {
        this.carRepository = carRepository;
        this.engineService = engineService;
    }

//    public List<CarDTO> getCars() {
//        return carRepository.findAll().stream().map(this::mapCar).collect(Collectors.toList());
//    }

    public Page<CarDTO> getCars(int page, int pageSize){
        return carRepository.findCars(PageRequest.of(page, pageSize));
    }

    public void addCar(CarRequest carRequest) {
        Car car = new Car();
        car.setModel(carRequest.getModel());
        car.setYear(carRequest.getYear());
        car.setDriveable(carRequest.isDriveable());
        car.setEngine(engineService.findEngine(carRequest.getEngineId()));
        carRepository.save(car);
    }

    public boolean updateCar(long id, CarRequest carRequest) {
        Car car=carRepository.findById(id).orElse(null);
        if(car!=null) {
            car.setModel(carRequest.getModel());
            car.setYear(carRequest.getYear());
            car.setDriveable(carRequest.isDriveable());
            car.setEngine(engineService.findEngine(carRequest.getEngineId()));
            carRepository.save(car);
            return true;
        }
        return false;
    }

    public boolean deleteCar(long id) {
        if(carRepository.existsById(id)) {
            carRepository.deleteById(id);
            return true;
        }
        return false;
    }


    public CarDTO findCar(long id) {
        Car car = carRepository.findById(id).orElse(null);
        if (car != null)
            return mapCar(car);
        return null;
    }

    private CarDTO mapCar(Car car){
        return new  CarDTO(car.getId(), car.getModel(), car.getYear(), car.isDriveable(),
                new EngineDTO(car.getEngine().getId(), car.getEngine().getHorsePower(), car.getEngine().getCapacity()));
    }
}
