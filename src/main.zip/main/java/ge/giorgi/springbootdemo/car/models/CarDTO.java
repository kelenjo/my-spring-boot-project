package ge.giorgi.springbootdemo.car.models;

public class CarDTO {
    private long id;
    private String model;
    private int year;
    private boolean driveable;
    private EngineDTO engineDTO;

    public CarDTO(long id, String model, int year, boolean driveable, EngineDTO engineDTO) {
        this.id=id;
        this.model = model;
        this.year = year;
        this.driveable = driveable;
        this.engineDTO = engineDTO;
    }


    public void setDriveable(boolean driveable) {
        this.driveable = driveable;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setEngine(EngineDTO engineDTO) {
        this.engineDTO = engineDTO;
    }

    public boolean isDriveable() {
        return driveable;
    }
    public long getId(){
        return id;
    }

    public String getModel() {
        return model;
    }

    public EngineDTO getEngine(){
        return engineDTO;
    }
    public int getYear() {
        return year;
    }

    public void printInfo(){
        System.out.println("Model " + model);
        System.out.println("Year " + year);
        engineDTO.printInf();
    }

}
