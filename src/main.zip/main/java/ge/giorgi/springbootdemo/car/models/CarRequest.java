package ge.giorgi.springbootdemo.car.models;

public class CarRequest {
    private String model;
    private int year;
    private boolean driveable;
    private Long EngineId;

    public CarRequest(String model, int year, boolean driveable, long EngineId) {
        this.model = model;
        this.year = year;
        this.driveable = driveable;
        this.EngineId = EngineId;
    }


    public void setDriveable(boolean driveable) {
        this.driveable = driveable;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setEngineId(long EngineID) {
        this.EngineId = EngineID;
    }

    public boolean isDriveable() {
        return driveable;
    }

    public String getModel() {
        return model;
    }

    public long getEngineId(){
        return EngineId;
    }
    public int getYear() {
        return year;
    }

    public void printInfo(){
        System.out.println("Model " + model);
        System.out.println("Year " + year);
//        engineDTO.printInf();
    }

}
