package ge.giorgi.springbootdemo.car;


import ge.giorgi.springbootdemo.car.models.CarDTO;
import ge.giorgi.springbootdemo.car.models.CarRequest;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cars")
public class CarController {

    private final CarService carService;

    public CarController(CarService carService){
        this.carService=carService;
    }

    @PostMapping
    public ResponseEntity<String> addCar(@RequestBody CarRequest carRequest) {
        carService.addCar(carRequest);
        return ResponseEntity.ok("Car added successfully!");
    }

    @PutMapping("{id}")
    public ResponseEntity<String> updateCar(@PathVariable int id, @RequestBody CarRequest carRequest) {
        if (carService.updateCar(id, carRequest)==false) {
            return ResponseEntity.notFound().build(); // 404 if car not found
        }
        return ResponseEntity.ok("Car updated successfully!");
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteCar(@PathVariable int id) {
        if (carService.deleteCar(id) == false) {
            return ResponseEntity.notFound().build(); // 404 if car not found
        }
        return ResponseEntity.ok("Car deleted successfully!");
    }

    @GetMapping("{id}")
    ResponseEntity<CarDTO> getCar(@PathVariable int id){
        CarDTO cartofind=carService.findCar(id);
        if(cartofind!=null)
            return ResponseEntity.ok(cartofind);
        return ResponseEntity.notFound().build();
    }
//    @GetMapping
//    public List<CarDTO> getCars(){
//        return carService.getCars();
//    }

    @GetMapping
    public Page<CarDTO> getCars(@RequestParam int page, @RequestParam int pageSize){
        return carService.getCars(page, pageSize);
    }
}
