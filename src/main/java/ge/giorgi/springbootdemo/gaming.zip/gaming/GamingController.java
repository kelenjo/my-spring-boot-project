package ge.giorgi.springbootdemo.gaming;

import ge.giorgi.springbootdemo.gaming.models.Company;
import ge.giorgi.springbootdemo.gaming.models.Game;
import ge.giorgi.springbootdemo.gaming.models.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/gaming")
public class GamingController {


    private final GamingService gamingService;

    public GamingController(GamingService gamingService){
        this.gamingService=gamingService;
    }

    @PostMapping("/{companyId}/addGame")
    public ResponseEntity<String> addGame(@PathVariable int companyId, @RequestBody  Game game){
        if(gamingService.addGame(companyId, game))
            return ResponseEntity.ok("Game added successfully");
        return ResponseEntity.badRequest().body("Something went wrong");
    }

    @PostMapping("/addCompany")
    public ResponseEntity<String> addCompany(@RequestBody Company company){
        if(gamingService.addCompany(company)){
            return ResponseEntity.ok("Company added successfully");
        }
        return ResponseEntity.badRequest().body("Company already exists");
    }

    @PutMapping("/{companyId}")
    public ResponseEntity<String> changeCompanyOwner(@PathVariable int companyId, @RequestBody Person person){
        if(gamingService.changeCompanyOwner(companyId, person)){
            return ResponseEntity.ok("Owner Changed successfully");
        }
        return ResponseEntity.badRequest().body("Something Went Wrong");
    }

    @DeleteMapping("/{companyId}")
    public ResponseEntity<String> deleteCompany(@PathVariable int companyId){
        if(gamingService.deleteCompany(companyId)){
            return ResponseEntity.ok("Company deleted successfully");
        }
        return ResponseEntity.badRequest().body("Company doesn't exists");
    }

    @DeleteMapping("/{companyId}/{gameId}")
    public ResponseEntity<String> deleteGame(@PathVariable int companyId, @PathVariable int gameId){
       if(gamingService.deleteGame(companyId, gameId)){
           return ResponseEntity.ok("Game deleted successfully");
       }
        return ResponseEntity.badRequest().body("Game doesn't exists");//tamashi ar arsebobs;)
    }

    @GetMapping("/{companyId}")
    public ResponseEntity<Company> getCompany(@PathVariable int companyId){
        Company companyToGet=gamingService.findCompany(companyId);
        if(companyToGet!=null){
            return ResponseEntity.ok(companyToGet);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/{companyId}/{gameId}")
    public ResponseEntity<Game> getGame(@PathVariable int companyId, @PathVariable int gameId){
        Game gameToGet=gamingService.findGame(companyId, gameId);
        if(gameToGet!=null){
            return ResponseEntity.ok(gameToGet);
        }
        return ResponseEntity.notFound().build();//ver moidzebna
    }

    @GetMapping
    public List<Company> getCompanies(){
        return gamingService.getCompanies();
    }
}
