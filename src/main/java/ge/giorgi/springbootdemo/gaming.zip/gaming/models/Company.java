package ge.giorgi.springbootdemo.gaming.models;

import java.util.ArrayList;
import java.util.List;

public class Company {
    private int id;
    private String name;
    private Person owner;
    private List<Game> games;

    public Company(){}
    public Company(int id, String name, Person owner) {
        this.id=id;
        this.name = name;
        this.owner = owner;
        this.games = new ArrayList<>();
    }

    public Company(int id, String name, Person owner, List<Game> games) {
        this.id=id;
        this.name = name;
        this.owner = owner;
        this.games = new ArrayList<>(games);
    }


    public int getid(){
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Person getOwner() {
        return owner;
    }

    public void setOwner(Person owner) {
        this.owner = owner;
    }

    public List<Game> getGames() {
        return games;
    }

    public void setGames(List<Game> games) {
        this.games = games;
    }

    public boolean addGame(Game game) {
        if(games.contains(game)){
            System.out.println("Game already exists");
            return false;
        }else{
            this.games.add(game);
            System.out.println("Successfully added");
            return true;
        }
    }

    public boolean removeGame(int gameId) {
        Game gameToRemove=findGame(gameId);
        if(gameToRemove!=null) {
            this.games.remove(gameToRemove);
            System.out.println("Successfully removed");
            return true;
        }else{
            System.out.println("We don't have that game :(");
            return false;
        }
    }

    public Game findGame(int gameId){
        for(Game game:games){
            if(game.getId()==gameId)
                return game;
        }
        return null;
    }

    public boolean changeOwner(Person person){
        this.owner=person;
        return true;//ar unda shemowmeba dd
    }

    public void displayGames() {
        System.out.println("Games developed by " + name + ":");
        for (Game game : games) {
            System.out.println(game);
        }
    }

    // toString Method
    @Override
    public String toString() {
        return "Company{" + "name='" + name + '\'' + ", owner=" + owner + ", games=" + games.size() + '}';
    }

}
