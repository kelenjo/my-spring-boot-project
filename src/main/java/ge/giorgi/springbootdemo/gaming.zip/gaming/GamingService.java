package ge.giorgi.springbootdemo.gaming;

import ge.giorgi.springbootdemo.gaming.models.Company;
import ge.giorgi.springbootdemo.gaming.models.Game;
import ge.giorgi.springbootdemo.gaming.models.Person;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class GamingService {

    private List<Company> companies=new ArrayList<>();

    @PostConstruct
    public void setUp(){
        Person owner1 = new Person("vigac qartveli", 35);
        Person owner2 = new Person("Dave Hagewood", 48);
        Person owner3 = new Person("Tim Sweeney", 55);

        Game game1 = new Game(1,"nela zviadi 2", "", 2019);
        Game game2 = new Game(2,"Rocket League", "Vehicle, football", 2015);
        Game game3 = new Game(3,"Monster Maddness", "Shooting", 2008);
        Game game4 = new Game(4,"Fortnite", "BattleGround", 2017);
        Game game5 = new Game(5,"Fall guys", "Survival", 2020);

        Company company1 = new Company(1, "qartuli komiqsebi", owner1);
        company1.addGame(game1);

        Company company2 = new Company(2, "Psyonix", owner2);
        company2.addGame(game2);
        company2.addGame(game3);

        Company company3 = new Company(3, "Epic games", owner3);
        company3.addGame(game4);
        company3.addGame(game5);

        // Add companies to the list
        companies.add(company1);
        companies.add(company2);
        companies.add(company3);
    }

    public boolean changeCompanyOwner(int companyId, Person person){
        Company company=findCompany(companyId);
        if(company!=null){
            return company.changeOwner(person);
        }
        return false;
    }

    public boolean deleteCompany(int companyId){
        return companies.remove(findCompany(companyId));
    }

    public boolean deleteGame(int companyId, int gameId){
        Company company=findCompany(companyId);
        if(company!=null){
            return company.removeGame(gameId);
        }
        return false;
    }
    public Company findCompany(int id){
        for(Company company : companies){
            if(company.getid()==id)
                return company;
        }
        return null;
    }

    public Game findGame(int companyId, int gameId){
        Company company=findCompany(companyId);
        if(company!=null){
            Game game=company.findGame(gameId);
            if(game!=null)
                return game;
        }
        return null;
    }

    public boolean addGame(int companyId, Game game){
        Company companyToAddGame=findCompany(companyId);
        if(companyToAddGame!=null){
            if(companyToAddGame.addGame(game))
                return true;
            return false;//tamashi arsebobs
        }
        return false;
    }

    public boolean addCompany(Company company){
        if(findCompany(company.getid())==null){
            companies.add(company);
            return true;
        }
        return false;
    }
    public List<Company> getCompanies() {
        return companies;
    }
}
