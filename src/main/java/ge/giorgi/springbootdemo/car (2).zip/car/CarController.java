package ge.giorgi.springbootdemo.car;


import ge.giorgi.springbootdemo.car.models.CarDTO;
import ge.giorgi.springbootdemo.car.models.CarRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cars")
@RequiredArgsConstructor
public class CarController {

    private final CarService carService;

//    public CarController(CarService carService){
//        this.carService=carService;
//    }

    @PostMapping
    public ResponseEntity<String> addCar(@RequestBody @Valid CarRequest carRequest) {
        carService.addCar(carRequest);
        return ResponseEntity.ok("Car added successfully!");
    }

    @PutMapping("{id}")
    public ResponseEntity<String> updateCar(@PathVariable long id, @RequestBody @Valid CarRequest carRequest) {
        carService.updateCar(id, carRequest);
        return ResponseEntity.ok("Car updated successfully!");
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteCar(@PathVariable long id) {
        carService.deleteCar(id);
        return ResponseEntity.ok("Car deleted successfully!");
    }

    @GetMapping("{id}")
    ResponseEntity<CarDTO> getCar(@PathVariable long id){
        CarDTO cartofind=carService.getCar(id);
        return ResponseEntity.ok(cartofind);
    }
//    @GetMapping
//    public List<CarDTO> getCars(){
//        return carService.getCars();
//    }

    @GetMapping
    public Page<CarDTO> getCars(@RequestParam int page, @RequestParam int pageSize){
        return carService.getCars(page, pageSize);
    }
}
