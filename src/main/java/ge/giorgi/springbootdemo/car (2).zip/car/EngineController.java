package ge.giorgi.springbootdemo.car;

import ge.giorgi.springbootdemo.car.models.CarDTO;
import ge.giorgi.springbootdemo.car.models.EngineDTO;
import ge.giorgi.springbootdemo.car.models.EngineRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/engines")
@RequiredArgsConstructor
public class EngineController {

    private final EngineService engineService;

//    @GetMapping
//    public List<EngineDTO> getEngines(){
//        return engineService.getEngines();
//    }

    @GetMapping
    public Page<EngineDTO> getEngines(@RequestParam int page, @RequestParam int pageSize, @RequestParam double capacity){
        return engineService.getEngines(page, pageSize, capacity);
    }

    @GetMapping("{id}")
    public ResponseEntity<EngineDTO> getEngine(@PathVariable long id){
        EngineDTO engine=engineService.getEngine(id);
        return ResponseEntity.ok(engine);

    }

    @PutMapping("{id}")
    public ResponseEntity<EngineDTO> updateEngine(@PathVariable long id, @RequestBody @Valid EngineRequest engineRequest){
        EngineDTO  engineDTO=engineService.updateEngine(id, engineRequest);
        return ResponseEntity.status(HttpStatus.OK).body(engineDTO);

    }
    @PostMapping
    public ResponseEntity<String> addEngine(@RequestBody @Valid EngineRequest engineRequest){
        engineService.createEngine(engineRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body("Engine added successfully");
    }

    @DeleteMapping("{id}")
    public ResponseEntity<Void> deleteEngine(@PathVariable long id){
        engineService.deleteEngine(id);
        return ResponseEntity.noContent().build();
    }



}
